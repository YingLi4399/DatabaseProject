package com.example.project2.Controllers;

import com.example.project2.Project2Application;
import com.example.project2.Services.BlockService;
import com.example.project2.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ApplicationController {

    private UserService userService;

    @Autowired
    public ApplicationController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/auth/application/friend")
    public String showFriendApplication(Model model) throws Exception{
        System.out.println("friend application page in?");
        if(Project2Application.currentUserID != 0){
            Object[][] result = userService.getFriendRequest(Project2Application.currentUserID);
            model.addAttribute("applications", result);
            return "friendApplication";
        }else {
            return "login";
        }


    }

    @PostMapping("/auth/application/friend-approve")
    public String approveFriendApplication(@RequestParam("userID") int userID,  Model model) throws Exception{
        System.out.println("friend application approve in?");

        System.out.println(userID);
        if(Project2Application.currentUserID != 0){
            userService.addFriend(Project2Application.currentUserID, userID);
            return "redirect:/auth/application/friend";
        }else {
            return "login";
        }


    }

    @PostMapping("/auth/application/friend-decline")
    public String declineFriendApplication(@RequestParam("userID") int userID,  Model model) throws Exception{
        System.out.println("friend application decline in?");

        System.out.println(userID);
        if(Project2Application.currentUserID != 0){
            userService.declineFriendRequest(Project2Application.currentUserID, userID);
            return "redirect:/auth/application/friend";
        }else {
            return "login";
        }


    }

    @GetMapping("/auth/application/block")
    public String showBlockApplication(Model model) throws Exception{
        System.out.println("blcok application page in?");

        if(Project2Application.currentUserID != 0){
            Object[][] applicators = userService.getBlockApplicators(Project2Application.currentUserID);
            model.addAttribute("applicators", applicators);
            return "blockApplication";
        }else {
            return "login";
        }

    }

    @GetMapping("/auth/application/block/{userID}/approve")
    public String approveBlockApplication(@PathVariable int userID, Model model) throws Exception{
        System.out.println("blcok application approve page in?");

        if(Project2Application.currentUserID != 0){
            System.out.println(userID);
            userService.approveBlockApplication(Project2Application.currentUserID, userID);
//            int result = userService.updateBlockApplication(userID);
//            System.out.println("result is " + result);
            return "redirect:/auth/application/block";
        }else {
            return "login";
        }

    }

    @GetMapping("/auth/application/block/{userID}/decline")
    public String declineBlockApplication(@PathVariable int userID, Model model) throws Exception{
        System.out.println("blcok application decline page in?");

        if(Project2Application.currentUserID != 0){
            userService.declineBlockApplication(Project2Application.currentUserID, userID);
            return "redirect:/auth/application/block";
        }else {
            return "login";
        }

    }
}
