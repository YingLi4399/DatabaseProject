package com.example.project2.Services;

import org.springframework.stereotype.Component;

import java.sql.*;
import java.util.Arrays;


@Component
public class MessageService {
    public  String url="jdbc:postgresql://localhost:5432/DatabaseProject";
    public  String user="postgres";
    public  String password="";//
    public  Connection con;
    public  Statement st;
    public  ResultSet rs;


    public MessageService() {
        try {
            // Create database connection
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Close resources
    public void close() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Object[][] generateArray() throws Exception{
        ResultSetMetaData rsmd = rs.getMetaData();
        int numColumns = rsmd.getColumnCount();
        Object[][] message;
        // get number of rows
        rs.last(); // move to the last row
        int numRows = rs.getRow(); // get the number of last row
        rs.beforeFirst(); // move pointer to 1st row

        // create a 2-array for the results
        message = new Object[numRows][numColumns];

        // store the msg to array
        int row = 0;
        while (rs.next()) {
            for (int col = 0; col < numColumns; col++) {
                message[row][col] = rs.getObject(col + 1); // index from 1

            }
//            System.out.println(Arrays.toString(message[row])); // print data  for test
            row++;
        }
        return message;
    }

    public Object[][] getAllFeed(int userID) throws Exception {

        String sql = "select *\n" +
                "from \"message\" as m\n" +
                "where msg_id in (select msg_id\n" +
                "\t\t\t\tfrom \"blockMessage\" b join \"userBlockRelation\" u on b.block_id = u.block_id\n" +
                "\t\t\t\twhere u.user_id = " + userID + "\n" +
                "\t\t\t\tand (u.status = 'follower' or u.status = 'member')\n" +
                "\t\t\t\tand msg_id not in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom accessibility\n" +
                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + "))\n" +
                "\t\tor msg_id in (select msg_id\n" +
                "\t\t\t\tfrom \"hoodMessage\" h join \"block\" b on h.hood_id = b.hood_id\n" +
                "\t\t\t\t join \"userBlockRelation\" u on b.block_id = u.block_id\n" +
                "\t\t\t\twhere u.user_id = " + userID + "\n" +
                "\t\t\t\tand (u.status = 'follower' or u.status = 'member')\n" +
                "\t\t\t\tand msg_id not in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom accessibility\n" +
                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + "))\n" +
                "\t\tor msg_id in (select msg_id\n" +
                "\t\t\t\t\t\tfrom \"accessibility\"\n" +
                "\t\t\t\t\t\twhere user_id = " + userID + "\n" +
                "\t\t\t\t\t\tand read = 'f')\n" +
                "and user_id != " + userID + "\n" +
                "order by \"timestamp\" desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;

    }

    public Object[][] getBlockFeed(int userID) throws Exception {

        String sql = "select *\n" +
                "from message\n" +
                "where msg_id in (select msg_id\n" +
                "\t\t\t\tfrom \"blockMessage\" b join \"userBlockRelation\" u on b.block_id = u.block_id\n" +
                "\t\t\t\twhere u.user_id = " + userID + "\n" +
                "\t\t\t\tand u.status != 'applied'\n" +
                "\t\t\t\tand msg_id not in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom accessibility\n" +
                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + "))\n" +
                "\tand user_id != " + userID + "\n" +
                "ORDER BY \"timestamp\" desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;

    }

    public Object[][] getHoodFeed(int userID) throws Exception {

        String sql = "select *\n" +
                "from message\n" +
                "where msg_id in (select msg_id\n" +
                "\t\t\t\tfrom \"hoodMessage\" h join \"block\" b on h.hood_id = b.hood_id\n" +
                "\t\t\t\t join \"userBlockRelation\" u on b.block_id = u.block_id\n" +
                "\t\t\t\twhere u.user_id = " + userID + "\n" +
                "\t\t\t\tand (u.status = 'follower' or u.status = 'member')\n" +
                "\t\t\t\tand msg_id not in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom accessibility\n" +
                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + "))\n" +
                "\tand user_id != " + userID + "\n" +
                "ORDER BY \"timestamp\" desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;

    }

    public Object[][] getNeighbourFeed(int userID) throws Exception {

        String sql = "select *\n" +
                "from message\n" +
                "where msg_id in (select msg_id\n" +
                "\t\t\t\tfrom accessibility\n" +
                "\t\t\t\twhere user_id = " + userID + "\n" +
                "\t\t\t\tand read = false)\n" +
                "  and (type = 'all neighbour' or type = 'certain_neighbour')\n" +
                "\tand user_id != " + userID + "\n" +
                "ORDER BY \"timestamp\" desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;

    }

    public Object[][] getFriendFeed(int userID) throws Exception {

        String sql = "select *\n" +
                "from message\n" +
                "where msg_id in (select msg_id\n" +
                "\t\t\t\tfrom accessibility\n" +
                "\t\t\t\twhere user_id = " + userID + "\n" +
                "\t\t\t\tand read = false)\n" +
                "  and (type = 'all friend' or type = 'certain_friend')\n" +
                "\tand user_id != " + userID + "\n" +
                "ORDER BY \"timestamp\" desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;

    }

    public Object[][] getMessageByID(int msgID) throws Exception {

        String sql = "select *\n" +
                "from message\n" +
                "where msg_id = " + msgID + "\n";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;

    }

    public Object[][] getReplyByMessageId(int msgID) throws Exception {
        String sql = "SELECT * FROM \"reply\" \n" +
                "where \"replyTo\" = 'msg'\n" +
                "\tand \"replyTo_id\" = " + msgID + "\norder by timestamp asc";

        rs = st.executeQuery(sql);
        Object[][] message = generateArray();
        return message;
    }

    public Object[][] getReplyByReplyId(int replyID) throws Exception {
        String sql = "select * \n" +
                "from \"reply\"\n" +
                "where \"replyTo\" = 'reply'\n" +
                " and \"replyTo_id\" = " + replyID + "\n" +
                "order by \"timestamp\" ASC";

        rs = st.executeQuery(sql);
        Object[][] message = generateArray();
        return message;
    }

    public void replyMsg(int userID, int msgID, String content) throws Exception {
        String sql = "insert into \"reply\" (\"user_id\", \"reply_content\", \"timestamp\", \"replyTo\", \"replyTo_id\")\n" +
                "values (" + userID + ", '" + content + "', CURRENT_TIMESTAMP, 'msg', " + msgID + ")";

        st.executeUpdate(sql);

    }

    public void replyReply(int userID, int replyID, String content) throws Exception {
        String sql = "insert into \"reply\" (\"user_id\", \"reply_content\", \"timestamp\", \"replyTo\", \"replyTo_id\")\n" +
                "values (" + userID + ", '" + content + "', CURRENT_TIMESTAMP, 'reply', " + replyID + ")";

        st.executeUpdate(sql);

    }




    public void composeGeneralMessage(int userID, String location, String msgTitle, String msgContent, String type) throws Exception {

        String sql = "insert into \"message\" (\"user_id\", \"msg_location\" , \"msg_title\", \"msg_content\", \"timestamp\", \"type\")\n" +
                "values (" + userID + ", '" + location + "', '" + msgTitle + "', '" + msgContent + "', CURRENT_TIMESTAMP, '" + type + "')";


        int result = st.executeUpdate(sql);



        System.out.println(result);

    }

    public void composePrivateMessage(int userID, String location, String msgTitle, String msgContent, String type, int anotherUserID) throws Exception {

        String sql = "insert into \"message\" (\"user_id\", \"msg_location\" , \"msg_title\", \"msg_content\", \"timestamp\", \"type\")\n" +
                "values (" + userID + ", '" + location + "', '" + msgTitle + "', '" + msgContent + "', CURRENT_TIMESTAMP, '" + type + "')";

        int result = st.executeUpdate(sql);

        sql = "select msg_id\n" +
                "from \"message\" \n" +
                "where user_id = " + userID + "\n" +
                "order by msg_id desc\n" +
                "limit 1";

        rs = st.executeQuery(sql);
        if(rs.next()) {
            result = rs.getInt("msg_id");
        }

        sql = "insert into \"accessibility\" (\"user_id\", \"msg_id\" , \"read\")\n" +
                "values (" + anotherUserID + ", " + result + ", 'f')";

        result = st.executeUpdate(sql);

        System.out.println(result);

    }

    public Object[][] searchAllMessageByTitle(int userID, String msgTitle) throws Exception{

        String sql = "select *\n" +
                "from \"message\" msg\n" +
                "where msg_title like '%" + msgTitle + "%'\n" +
                " and (msg.msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"blockMessage\" natural join \"userBlockRelation\"\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")\n" +
                " \t\t\tor msg.msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"hoodMessage\" h join \"block\" b on h.hood_id = b.hood_id\n" +
                "\t\t\t\t\t\t\t\t\t join \"userBlockRelation\" ub on b.block_id = ub.block_id\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")\n" +
                "\t\t\tor msg.msg_id in (select a.msg_id\n" +
                "\t\t\t\t\t\t\t\t\t\tfrom \"accessibility\"  a join \"message\" m on a.msg_id = m.msg_id\n" +
                "\t\t\t\t\t\t\t\t\t\tand a.user_id = " + userID + "))\n" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    public Object[][] searchNeighbourMessageByTitle(int userID, String msgTitle) throws Exception{

        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_title like '%" + msgTitle + "%'\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"accessibility\"\n" +
                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + ")\t\t\t\t\t\t\t\t\t\n" +
                " and (type = 'all neighbour' or type = 'certain_neighbour')" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    public Object[][] searchFriendMessageByTitle(int userID, String msgTitle) throws Exception{

        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_title like '%" + msgTitle + "%'\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"accessibility\"\n" +
                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + ")\t\t\t\t\t\t\t\t\t\n" +
                " and (type = 'all friend' or type = 'certain_friend')" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    public Object[][] searchBlockMessageByTitle(int userID, String msgTitle) throws Exception{

//        String sql = "select *\n" +
//                "from message\n" +
//                "where msg_title like '%" + msgTitle + "%'\n" +
//                "\tand msg_id in (select msg_id\n" +
//                "\t\t\t\tfrom \"blockMessage\" b join \"userBlockRelation\" u on b.block_id = u.block_id\n" +
//                "\t\t\t\twhere u.user_id = " + userID + "\n" +
//                "\t\t\t\tand (u.status = 'follower' or u.status = 'member')\n" +
//                "\t\t\t\tand msg_id not in (select msg_id\n" +
//                "\t\t\t\t\t\t\t\t\tfrom accessibility\n" +
//                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + "))\n" +
//                "\tand user_id != " + userID + "\n" +
//                "ORDER BY \"timestamp\" desc";

        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_title like '%" + msgTitle + "%'\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"blockMessage\" natural join \"userBlockRelation\"\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    public Object[][] searchHoodMessageByTitle(int userID, String msgTitle) throws Exception{

        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_title like '%" + msgTitle + "%'\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"hoodMessage\" h join \"block\" b on h.hood_id = b.hood_id\n" +
                "\t\t\t\t\t\t\t\t\t join \"userBlockRelation\" ub on b.block_id = ub.block_id\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    public Object[][] searchAllMessageByContent(int userID, String msgContent) throws Exception{



        String sql = "select *\n" +
                "from \"message\" msg\n" +
                "where msg_content like '%" + msgContent + "%'\n" +
                " and (msg.msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"blockMessage\" natural join \"userBlockRelation\"\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")\n" +
                " \t\t\tor msg.msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"hoodMessage\" h join \"block\" b on h.hood_id = b.hood_id\n" +
                "\t\t\t\t\t\t\t\t\t join \"userBlockRelation\" ub on b.block_id = ub.block_id\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")\n" +
                "\t\t\tor msg.msg_id in (select a.msg_id\n" +
                "\t\t\t\t\t\t\t\t\t\tfrom \"accessibility\"  a join \"message\" m on a.msg_id = m.msg_id\n" +
                "\t\t\t\t\t\t\t\t\t\tand a.user_id = " + userID + "))\n" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    public Object[][] searchNeighbourMessageByContent(int userID, String msgContent) throws Exception{



        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_content like '%" +msgContent + "%'\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"accessibility\"\n" +
                "\t\t\t\t\t\t\t\t\twhere user_id = " +userID + ")\t\t\t\t\t\t\t\t\t\n" +
                " and (type = 'all neighbour' or type = 'certain_neighbour')" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    public Object[][] searchFriendMessageByContent(int userID, String msgContent) throws Exception{



        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_content like '%" + msgContent + "%'\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"accessibility\"\n" +
                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + ")\t\t\t\t\t\t\t\t\t\n" +
                " and (type = 'all friend' or type = 'certain_friend')" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    public Object[][] searchBlockMessageByContent(int userID, String msgContent) throws Exception{

//        String sql = "select *\n" +
//                "from message\n" +
//                "where msg_content like '%" + msgContent + "%'\n" +
//                "\tand msg_id in (select msg_id\n" +
//                "\t\t\t\tfrom \"blockMessage\" b join \"userBlockRelation\" u on b.block_id = u.block_id\n" +
//                "\t\t\t\twhere u.user_id = " + userID + "\n" +
//                "\t\t\t\tand (u.status = 'follower' or u.status = 'member')\n" +
//                "\t\t\t\tand msg_id not in (select msg_id\n" +
//                "\t\t\t\t\t\t\t\t\tfrom accessibility\n" +
//                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + "))\n" +
//                "\tand user_id != " + userID + "\n" +
//                "ORDER BY \"timestamp\" desc";

        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_content like '%" + msgContent + "%'\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"blockMessage\" natural join \"userBlockRelation\"\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    public Object[][] searchHoodMessageByContent(int userID, String msgContent) throws Exception{



        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_content like '%" + msgContent + "%'\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"hoodMessage\" h join \"block\" b on h.hood_id = b.hood_id\n" +
                "\t\t\t\t\t\t\t\t\t join \"userBlockRelation\" ub on b.block_id = ub.block_id\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    //  location between the msg and the reader home location <= distance
    public Object[][] searchAllMessageByLocation(int userID, int distance) throws Exception{

        String sql = "\n" +
                "select msg.*\n" +
                "from \"message\" msg, \"user\" u\n" +
                "where sqrt((msg.msg_location[0] - u.user_location[0])^2 + (msg.msg_location[1] - u.user_location[1])^2) <= " + distance + "\n" +
                " and u.user_id = " + userID + "\n" +
                " and (msg.msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"blockMessage\" natural join \"userBlockRelation\"\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")\n" +
                " \t\t\tor msg.msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"hoodMessage\" h join \"block\" b on h.hood_id = b.hood_id\n" +
                "\t\t\t\t\t\t\t\t\t join \"userBlockRelation\" ub on b.block_id = ub.block_id\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")\n" +
                "\t\t\tor msg.msg_id in (select a.msg_id\n" +
                "\t\t\t\t\t\t\t\t\t\tfrom \"accessibility\"  a join \"message\" m on a.msg_id = m.msg_id\n" +
                "\t\t\t\t\t\t\t\t\t\tand a.user_id = " + userID + "))\n" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    //  location between the msg and the reader home location <= distance
    public Object[][] searchNeighbourMessageByLocation(int userID, int distance) throws Exception{

        String sql = "select m.*\n" +
                "from \"message\" m, \"user\" u\n" +
                "where sqrt((m.msg_location[0] - u.user_location[0])^2 + (m.msg_location[1] - u.user_location[1])^2) <= " + distance + "\n" +
                " and u.user_id = " + userID + "\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"accessibility\"\n" +
                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + ")\t\t\t\t\t\t\t\t\t\n" +
                " and (type = 'all neighbour' or type = 'certain_neighbour')" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    //  location between the msg and the reader home location <= distance
    public Object[][] searchFriendMessageByLocation(int userID, int distance) throws Exception{

        String sql = "select m.*\n" +
                "from \"message\" m, \"user\" u\n" +
                "where sqrt((m.msg_location[0] - u.user_location[0])^2 + (m.msg_location[1] - u.user_location[1])^2) <= " + distance + "\n" +
                " and u.user_id = " + userID + "\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"accessibility\"\n" +
                "\t\t\t\t\t\t\t\t\twhere user_id = " + userID + ")\t\t\t\t\t\t\t\t\t\n" +
                " and (type = 'all friend' or type = 'certain_friend')" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

//  location between the msg and the reader home location <= distance
    public Object[][] searchBlockMessageByLocation(int userID, int distance) throws Exception{

        String sql = "select m.*\n" +
                "from \"message\" m, \"user\" u\n" +
                "where sqrt((m.msg_location[0] - u.user_location[0])^2 + (m.msg_location[1] - u.user_location[1])^2) <= " + distance + "\n" +
                " and u.user_id = " + userID + "\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"blockMessage\" natural join \"userBlockRelation\"\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }

    //  location between the msg and the reader home location <= distance
    public Object[][] searchHoodMessageByLocation(int userID, int distance) throws Exception{

        String sql = "select m.*\n" +
                "from \"message\" m, \"user\" u\n" +
                "where sqrt((m.msg_location[0] - u.user_location[0])^2 + (m.msg_location[1] - u.user_location[1])^2) <= " + distance + "\n" +
                " and u.user_id = " + userID + "\n" +
                " and msg_id in (select msg_id\n" +
                "\t\t\t\t\t\t\t\t\tfrom \"hoodMessage\" h join \"block\" b on h.hood_id = b.hood_id\n" +
                "\t\t\t\t\t\t\t\t\t join \"userBlockRelation\" ub on b.block_id = ub.block_id\n" +
                "\t\t\t\t\t\t\t\t\twhere (status = 'follower' or status = 'member') \n" +
                "\t\t\t\t\t\t\t\t\t and user_id = " + userID + ")\t" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();

        return message;
    }


    public Object[][] getAllAccessibleHoodPosts(int userID) throws Exception{
        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_id in (select msg_id\n" +
                "         from \"hoodMessage\" h join \"block\" b on h.hood_id = b.hood_id\n" +
                "          join \"userBlockRelation\" ub on b.block_id = ub.block_id\n" +
                "         where (status = 'follower' or status = 'member') \n" +
                "          and user_id = "+ userID +")\n" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();
        return message;
    }

    public Object[][] getAllAccessibleBlockPosts(int userID) throws Exception{
        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_id in (select msg_id\n" +
                "         from \"blockMessage\" natural join \"userBlockRelation\"\n" +
                "         where (status = 'follower' or status = 'member') \n" +
                "          and user_id = "+ userID +")\n" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();
        return message;
    }

    public Object[][] getAllAccessibleFriendPosts(int userID) throws Exception{
        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_id in (select msg_id\n" +
                "         from \"accessibility\"\n" +
                "         where user_id = "+ userID +")         \n" +
                " and (type = 'all friend' or type = 'certain_friend')\n" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();
        return message;
    }

    public Object[][] getAllAccessibleNeighbourPosts(int userID) throws Exception{
        String sql = "select *\n" +
                "from \"message\"\n" +
                "where msg_id in (select msg_id\n" +
                "         from \"accessibility\"\n" +
                "         where user_id = "+ userID +")         \n" +
                " and (type = 'all neighbour' or type = 'certain_neighbour')\n" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();
        return message;
    }

    public Object[][] getAllAccessiblePosts(int userID) throws Exception{
        String sql = "select *\n" +
                "from \"message\" msg\n" +
                "where (msg.msg_id in (select msg_id\n" +
                "         from \"blockMessage\" natural join \"userBlockRelation\"\n" +
                "         where (status = 'follower' or status = 'member') \n" +
                "          and user_id = "+ userID +")\n" +
                "    or msg.msg_id in (select msg_id\n" +
                "         from \"hoodMessage\" h join \"block\" b on h.hood_id = b.hood_id\n" +
                "          join \"userBlockRelation\" ub on b.block_id = ub.block_id\n" +
                "         where (status = 'follower' or status = 'member') \n" +
                "          and user_id = "+ userID +")\n" +
                "   or msg.msg_id in (select a.msg_id\n" +
                "          from \"accessibility\"  a join \"message\" m on a.msg_id = m.msg_id\n" +
                "          and a.user_id = "+ userID +"))\n" +
                "order by timestamp desc";

        rs=st.executeQuery(sql);
        Object[][] message = generateArray();
        return message;
    }

    public void changeMsgRead(int userID, int msgID) throws Exception{

        String sql = "select * from accessibility\n" +
                "where user_id = " + userID + "\n" +
                " and msg_id = " + msgID;

        rs=st.executeQuery(sql);
        if(rs.next()){
            sql = "update accessibility\n" +
                    "set read = 't'\n" +
                    "where user_id = " + userID + "\n" +
                    " and msg_id = " + msgID;
            st.executeUpdate(sql);
        }else{
            sql = "insert into accessibility (user_id, msg_id, read)\n" +
                    "values(" + userID + ", " + msgID + ", 't')\n";
            st.executeUpdate(sql);
        }

    }

    public int getBlockIn(int userID) throws Exception {

        String sql = "select * from \"userBlockRelation\"\n" +
                "where status = 'member'\n" +
                " and user_id = " + userID;

        rs = st.executeQuery(sql);
        if (rs.next()) {
            return 0;
        }
        return -1;
    }
}