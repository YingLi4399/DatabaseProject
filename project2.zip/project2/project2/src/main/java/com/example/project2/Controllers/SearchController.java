package com.example.project2.Controllers;

import com.example.project2.Project2Application;
import com.example.project2.Services.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SearchController {


    private final MessageService messageService;
    private final Project2Application project2Application;

    @Autowired
    public SearchController(MessageService messageService, Project2Application project2Application) {
        this.messageService = messageService;
        this.project2Application = project2Application;
    }

    @GetMapping("/auth/search")
    public String searchPost() {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        return "search";  // Ensure there is a 'search.html' under `src/main/resources/templates`
    }

    @PostMapping("/auth/search")
    public String searchBlockMessageByContent(@RequestParam("searchQuery") String searchQuery,
                                              @RequestParam("searchType") String searchType,
                                              @RequestParam("msgType") String msgType,
                                              Model model) throws Exception {
//        Object[][] results = messageService.searchBlockMessageByContent(2, searchQuery); // Adjust parameters as needed
//        model.addAttribute("messages", results);
//        return "feed";  // Ensure you have a view template for search-results



//
        Object[][] results = null;


        if(searchType.equals("search_title_keyword")){
            if(msgType.equals("all")){
                results = messageService.searchAllMessageByTitle(Project2Application.currentUserID, searchQuery);
            }else if(msgType.equals("neighbour")){
                results = messageService.searchNeighbourMessageByTitle(Project2Application.currentUserID, searchQuery);
            }else if(msgType.equals("friend")){
                results = messageService.searchFriendMessageByTitle(Project2Application.currentUserID, searchQuery);
            }else if (msgType.equals("block")){
                results = messageService.searchBlockMessageByTitle(Project2Application.currentUserID, searchQuery);
            }else{// hood
                results = messageService.searchHoodMessageByTitle(Project2Application.currentUserID, searchQuery);

            }


        }else if(searchType.equals("search_content_keyword")){
            if(msgType.equals("all")){
                results = messageService.searchAllMessageByContent(Project2Application.currentUserID, searchQuery);
            }else if(msgType.equals("neighbour")){
                results = messageService.searchNeighbourMessageByContent(Project2Application.currentUserID, searchQuery);

            }else if(msgType.equals("friend")){
                results = messageService.searchFriendMessageByContent(Project2Application.currentUserID, searchQuery);

            }else if (msgType.equals("block")){
                results = messageService.searchBlockMessageByContent(Project2Application.currentUserID, searchQuery);
            }else{
                results = messageService.searchHoodMessageByContent(Project2Application.currentUserID, searchQuery);
            }

        }else if(searchType.equals("geographicalProximity")){
            if(msgType.equals("all")){
                results = messageService.searchAllMessageByLocation(Project2Application.currentUserID, Integer.parseInt(searchQuery));
            }else if(msgType.equals("neighbour")){
                results = messageService.searchNeighbourMessageByLocation(Project2Application.currentUserID, Integer.parseInt(searchQuery));

            }else if(msgType.equals("friend")){
                results = messageService.searchFriendMessageByLocation(Project2Application.currentUserID, Integer.parseInt(searchQuery));

            }else if (msgType.equals("block")){
                results = messageService.searchBlockMessageByLocation(Project2Application.currentUserID, Integer.parseInt(searchQuery));

            }else{
                results = messageService.searchHoodMessageByLocation(Project2Application.currentUserID, Integer.parseInt(searchQuery));

            }
        }

        // Adjust parameters as needed
        System.out.println(searchType);
        System.out.println(searchQuery);
        System.out.println(msgType);

        if(results.length!=0){
            model.addAttribute("message", results);
        }
        System.out.println("results length is " + results.length);
        return "message";  // Ensure you have a view template for search-results
    }
}
