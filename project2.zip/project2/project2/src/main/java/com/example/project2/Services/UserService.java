package com.example.project2.Services;

import com.example.project2.Project2Application;
import org.springframework.stereotype.Component;

import java.sql.*;


@Component
public class UserService {
    public  String url="jdbc:postgresql://localhost:5432/DatabaseProject";
    public  String user="postgres";
    public  String password="";//
    public  Connection con;
    public  Statement st;
    public  ResultSet rs;


    public UserService() {
        try {
            // Create database connection
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Close resources
    public void close() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int loginCheck(String account, String passcode) throws Exception {
//    	result number indicate what result is returned, you need to write result msgbox based on different result;
//    	0=password correct
//    	1=password incorrect
//    	2=account doesnt exist

        String sql = "SELECT \"password\" FROM \"user\" WHERE \"account\" = '" + account + "'";
        rs=st.executeQuery(sql);
//		you need to call rs.next() to get a row of result set, if its false, then there is no row or end of row
        if(rs.next()) {
            String pass = rs.getString("password");
            if(passcode.equals(pass)) {
                System.out.println("password is correct");
                return 0;
            }else {
                System.out.println("password is incorrect");
                return 1;
            }

        }else {
            System.out.println("user account doesn't exist");
            return 2;
        }

    }

    public int getUserID(String account) throws Exception {

        String sql = "SELECT \"user_id\" FROM \"user\" WHERE \"account\" = '" + account + "'";
        rs=st.executeQuery(sql);
//		you need to call rs.next() to get a row of result set, if its false, then there is no row or end of row
        if(rs.next()) {
            return rs.getInt("user_id");


        }
        return 0;

    }

    public int register(String account, String passcode, String firstName, String lastName, String email, String address, String location) throws Exception {
//      result number indicate what result is returned, you need to write result msgbox based on different result;
//      0=fail, already exist that account
//      1=success


        String sql = "select account from \"user\" where account = '" + account + "'";
        rs = st.executeQuery(sql);


        if(rs.next()) {

        }else{
            System.out.println("in");
            sql = "insert into \"user\" (\"user_first_name\", \"user_last_name\", \"account\", \"email\", \"password\", \"user_address\", \"user_location\")\n" +
                    "values('" + firstName + "', '" + lastName + "', '" + account + "', '" + email + "', '" + passcode + "', '" + address+ "', '" + location+ "')";
            st.executeUpdate(sql);
            return 1;
        }


        return 0;
    }

    public int changePassword(String account, String email, String passcode) throws Exception {
//    	result number indicate what result is returned, you need to write result msgbox based on different result;
//    	0=successed
//    	1=user doesn't exist
//    	2=email is not correct

        String sql = "select account from \"user\" where account = '" + account + "'";
        rs = st.executeQuery(sql);


        if(rs.next()) {
            sql = "select email from \"user\" where account = '" + account + "'";
            rs = st.executeQuery(sql);
            if(rs.next()){
                if(email.equals(rs.getString("email"))){
                    sql = "update \"user\"\n" +
                            "set password = '" + passcode + "'\n" +
                            "where account = '" + account + "'";
                    st.executeUpdate(sql);
                    return 0;
                }else{
                    return 2;
                }
            }
        }else{
            return 1;
        }

        return 2;
    }


    public Object[][] generateArray() throws Exception{
        ResultSetMetaData rsmd = rs.getMetaData();
        int numColumns = rsmd.getColumnCount();
        Object[][] message;
        // get number of rows
        rs.last(); // move to the last row
        int numRows = rs.getRow(); // get the number of last row
        rs.beforeFirst(); // move pointer to 1st row

        // create a 2-array for the results
        message = new Object[numRows][numColumns];

        // store the msg to array
        int row = 0;
        while (rs.next()) {
            for (int col = 0; col < numColumns; col++) {
                message[row][col] = rs.getObject(col + 1); // index from 1

            }
//            System.out.println(Arrays.toString(message[row])); // print data  for test
            row++;
        }
        return message;
    }

    public Object[][] getNeighbours(int userID) throws Exception {

        String sql = "SELECT u.user_id, ur.bidirection, u.user_first_name, u.user_last_name\n" +
                "FROM \"userRelation\" ur join \"user\" u on ur.another_user_id = u.user_id\n" +
                "where ur.user_id = " + userID + "\n" +
                "\tand relation = 'neighbour'";

        rs=st.executeQuery(sql);
        return generateArray();

    }

    public Object[][] getFriends(int userID) throws Exception {

        String sql = "SELECT u.user_id, ur.bidirection, u.user_first_name, u.user_last_name\n" +
                "FROM \"userRelation\" ur join \"user\" u on ur.another_user_id = u.user_id\n" +
                "where ur.user_id = " + userID + "\n" +
                "\tand relation = 'friend'\n" +
                "\tand bidirection = 't'";

        rs=st.executeQuery(sql);
        return generateArray();

    }

//    public Object[][] getUserInfo(int userID) throws Exception {
//
//        String sql = "select * from \"userBlockRelation\"\n" +
//                "where user_id = " + userID + "\n" +
//                " and status = 'member'";
//        rs = st.executeQuery(sql);
//
//        if(rs.next()) {
//            System.out.println("user info exist, in get user info");
//            sql = "select u.*, ub.*, b.*, h.*\n" +
//                    "from \"user\" u natural join \"userBlockRelation\" ub natural join \"block\" b join \"hood\" h on b.hood_id = h.hood_id\n" +
//                    "where status = 'member'\n" +
//                    " and u.user_id = " + userID;
//            rs = st.executeQuery(sql);
//            return generateArray();
//
//        }else{
//            System.out.println("user info exist, in get user info");
//            sql = "select * from \"user\"\n" +
//                    "where user_id = " + userID;
//            rs = st.executeQuery(sql);
//            return generateArray();
//        }
//
//
//    }

    public Object[][] getUserInfo(int userID) throws Exception {

        String sql = "select * from \"userBlockRelation\"\n" +
                "where user_id = " + userID + "\n" +
                " and status = 'member'";
        rs = st.executeQuery(sql);

        if(rs.next()) {
            System.out.println("user info exist, in get user info");
            sql = "select u.*, ub.*, b.*, h.*\n" +
                    "from \"user\" u natural join \"userBlockRelation\" ub natural join \"block\" b join \"hood\" h on b.hood_id = h.hood_id\n" +
                    "where status = 'member'\n" +
                    " and u.user_id = " + userID;
            rs = st.executeQuery(sql);
            return generateArray();

        }else{
            System.out.println("user info exist, in get user info");
            sql = "select * from \"user\"\n" +
                    "where user_id = " + userID;
            rs = st.executeQuery(sql);
            return generateArray();
        }

    }

    public int getUserRelation(int userID) throws Exception {

        if (userID == Project2Application.currentUserID){
            return 0; // userID is himself
        }

        String sql = "select * from public.\"userRelation\"\n" +
                "where user_id = " + Project2Application.currentUserID + " and another_user_id = " + userID;

        rs=st.executeQuery(sql);
        Object[][] result = generateArray();
        if (result == null || result.length == 0) {
            return 1; // user doesn't have relation
        }
        else {
            String relationType = (String) result[0][2];
            boolean isBidirectional = (Boolean) result[0][3];

            if ("neighbour".equals(relationType)) {
                return 2; // user is neighbor of this account page
            } else if (isBidirectional) {
                return 3; // bidirectional is true
            } else {
                return 4; // other types of relations or unidirectional
            }
        }
    }


    public Object[][] getAllAddresses() throws Exception {
        String sql = "SELECT description, block_location\n" +
                "FROM public.\"block\"";
        rs=st.executeQuery(sql);
        return generateArray();
    }


    public void updateUserDetails(int userID, String address, String location, String familyDescription) throws Exception {
        System.out.println(userID +" " + address + " " + location + " " + familyDescription);
        String sql = "update \"user\"\n" +
                "set user_location = '" + location + "',\n" +
                "\tuser_address = '" + address + "',\n" +
                "\tfamily_description = '" + familyDescription + "'\n" +
                "where user_id = " + userID;
        st.executeUpdate(sql);
        System.out.println("finished");
    }

    public void addNeighbour(int currentUserID, int userID) throws Exception{
        String sql = "insert into \"userRelation\" (user_id, another_user_id, relation, bidirection)\n" +
                "VALUES (" + currentUserID + "," + userID + ", 'neighbour', 'f')";

        st.executeUpdate(sql);

    }

    public void unNeighbour(int currentUserID, int userID) throws Exception{
        String sql = "delete from \"userRelation\"\n" +
                "where user_id = " + currentUserID + "\n" +
                " and another_user_id = " + userID;

        st.executeUpdate(sql);

    }

    public void addFriend(int currentUserID, int userID) throws Exception{
        String sql = "SELECT * FROM \"userRelation\"\n" +
                "where user_id = " + userID + "\n" +
                " and another_user_id = " + currentUserID + "\n" +
                " and bidirection = 'f'";

        rs = st.executeQuery(sql);
        if(rs.next()){
            sql = "insert into \"userRelation\" (user_id, another_user_id, relation, bidirection)\n" +
                    "VALUES (" + currentUserID + "," + userID + ", 'friend', 't')";
            st.executeUpdate(sql);
            sql = "update \"userRelation\"\n" +
                    "set bidirection = 't'\n" +
                    "where user_id = " + userID + "\n" +
                    " and another_user_id = " + currentUserID;
            st.executeUpdate(sql);
        }else{
            sql = "insert into \"userRelation\" (user_id, another_user_id, relation, bidirection)\n" +
                    "VALUES (" + currentUserID + "," + userID + ", 'friend', 'f')";
            st.executeUpdate(sql);

        }
    }

    public void unFriend(int currentUserID, int userID) throws Exception{
        String sql = " \n" +
                "delete from \"userRelation\"\n" +
                "where user_id = " + userID + "\n" +
                " and another_user_id = " + currentUserID;

        st.executeUpdate(sql);

        sql = "delete from \"userRelation\"\n" +
                "where user_id = " + currentUserID + "\n" +
                " and another_user_id = " + userID;

        st.executeUpdate(sql);

    }

    public void cancelFriendRequest(int currentUserID, int userID) throws Exception{
        String sql = "delete from \"userRelation\"\n" +
                "where user_id = " + currentUserID + "\n" +
                " and another_user_id = " + userID;

        st.executeUpdate(sql);

    }

    public void declineFriendRequest(int currentUserID, int userID) throws Exception{
        String sql = "delete from \"userRelation\"\n" +
                "where user_id = " + userID + "\n" +
                " and another_user_id = " + currentUserID;
        st.executeUpdate(sql);

    }

    public Object[][] getFriendRequest(int userID) throws Exception{
        String sql = "select * from \"userRelation\" ur join \"user\" u on ur.user_id = u.user_id\n" +
                "where bidirection = 'f'\n" +
                " and relation = 'friend'" +
                " and another_user_id = " + userID;

        rs = st.executeQuery(sql);
        return generateArray();

    }

    public Object[][] getBlockApplicators(int userID) throws Exception{
        String sql = "select * from \"blockApplication\" b join \"user\" u on b.user_id = u.user_id\n" +
                "where viewer_id = " + userID + "\n" +
                " and status = 'undecided'";
        rs = st.executeQuery(sql);
        return generateArray();
    }

    public int updateBlockApplication(int userID) throws Exception{
        String sql = "SELECT\n" +
                "    COUNT(*) AS total_rows,\n" +
                "    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_rows,\n" +
                "\t\tSUM(CASE WHEN status = 'undecided' THEN 1 ELSE 0 END) AS undecided_rows,\n" +
                "\t\tblock_id\n" +
                "FROM\n" +
                "    \"blockApplication\"\n" +
                "\t\t\n" +
                "WHERE\n" +
                "    user_id = " + userID + "\n" +
                "group by block_id";

        rs = st.executeQuery(sql);
        if(rs.next()){
            int totalRows = rs.getInt("total_rows");
            int approvedRows = rs.getInt("approved_rows");
            int undecidedRows = rs.getInt("undecided_rows");
            int blockID = rs.getInt("block_id");
            //print preceding 4 variables
            System.out.println(totalRows + " " + approvedRows + " " + undecidedRows + " " + blockID);
            if(approvedRows>=3 || approvedRows >= totalRows){
                sql = "delete from \"blockApplication\"\n" +
                        "where user_id = " + userID;
                st.executeUpdate(sql);
                sql = "update \"userBlockRelation\"\n" +
                        "set status = 'member'\n" +
                        " where user_id = " + userID + "\n" +
                        "  and block_id = " + blockID;
                st.executeUpdate(sql);
                return 0; // member joined
            }else if(undecidedRows == 0){
                sql = "delete from \"blockApplication\"\n" +
                        "where user_id = " + userID;
                st.executeUpdate(sql);
                sql = "delete from \"userBlockRelation\"\n" +
                        "where user_id = " + userID + "\n" +
                        " and status = 'applied'";
                st.executeUpdate(sql);
                return 1; // member declined
            }
            return 2; // nothing changed
        }
        return -1;
    }

    public void approveBlockApplication(int currentUserID, int userID) throws Exception{
        String sql = " update \"blockApplication\"\n" +
                "set status = 'approved'\n" +
                " where user_id = " + userID + "\n" +
                "  and viewer_id = " + currentUserID;
        st.executeUpdate(sql);
        updateBlockApplication(userID);
    }

    public void declineBlockApplication(int currentUserID, int userID) throws Exception{
        String sql = " update \"blockApplication\"\n" +
                "set status = 'declined'\n" +
                " where user_id = " + userID + "\n" +
                "  and viewer_id = " + currentUserID;
        st.executeUpdate(sql);
        updateBlockApplication(userID);

    }

    public int getUserBlockStatus(int userID, int blockID) throws Exception {
        String sql = "select status from \"userBlockRelation\" \n" +
                "where user_id = " + userID + "\n" +
                " and (status = 'applied' or status = 'member')\n" +
                " and block_id != " + blockID;
        rs = st.executeQuery(sql);
        boolean applied = false;
        if(rs.next()){
            applied = true;
        }

        sql = "select status from \"userBlockRelation\"\n" +
                "where user_id = " + userID + "\n" +
                " and block_id = " + blockID;
        rs = st.executeQuery(sql);
        if(rs.next()){
            String status = rs.getString("status");
            if(status.equals("member")){
                return 1;
            }else if(status.equals("follower")){

                return 2;
            }else { // applied

                    return 3;
            }

        }else{
            if(applied){
                return -1;
            }
        }



        return 0;

    }

    public boolean getUserHoodStatus(int userID, int hoodID) throws Exception {
        String sql = "select status from \"userBlockRelation\" ub join \"block\" b on ub.block_id = b.block_id \n" +
                "join \"hood\" h on b.hood_id = h.hood_id\n" +
                "where ub.user_id = " + userID + "\n" +
                " and b.hood_id = " + hoodID;
        rs = st.executeQuery(sql);
        if(rs.next()){
            String status = rs.getString("status");
            if(status.equals("member")){
                return true;
            }else if(status.equals("follower")){
                return true;
            }else { // applied
                return false;
            }
        }
        return false;

    }
    public void followBlock(int userID, int blockID) throws Exception{
        String sql = "insert into \"userBlockRelation\" (user_id, block_id, status)\n" +
                "values(" + userID + ", " + blockID + ", 'follower')";
        st.executeUpdate(sql);

    }

    public void unfollowBlock(int userID, int blockID) throws Exception{
        String sql = "delete from \"userBlockRelation\"\n" +
                "where user_id = " + userID + "\n" +
                " and status = 'follower'";
        st.executeUpdate(sql);

    }

    public void unmemberBlock(int userID, int blockID) throws Exception{
        String sql = "delete from \"userBlockRelation\"\n" +
                "where user_id = " + userID + "\n" +
                " and status = 'member'";
        st.executeUpdate(sql);

    }

    public void applyBlock(int userID, int blockID) throws Exception{
        String sql = "INSERT INTO \"blockApplication\" (user_id, block_id, viewer_id, status)\n" +
                "SELECT " + userID + " as user_id, block_id, user_id AS viewer_id, 'undecided' AS status\n" +
                "FROM \"userBlockRelation\"\n" +
                "WHERE block_id = " + blockID + " AND status = 'member';";
        st.executeUpdate(sql);
        sql = "INSERT INTO \"userBlockRelation\" (user_id, block_id, status)\n" +
                "values(" + userID + ", " + blockID + ", 'applied');\n";
        st.executeUpdate(sql);
        if(updateBlockApplication(userID)==-1){
            sql = "update \"userBlockRelation\"\n" +
                    "set status = 'member'\n" +
                    "where user_id = " + userID + "\n" +
                    " and block_id = " + blockID + "\n" +
                    " and status = 'applied'\n";
            st.executeUpdate(sql);
        }

    }



}

