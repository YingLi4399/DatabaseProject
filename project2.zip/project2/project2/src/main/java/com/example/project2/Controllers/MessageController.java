package com.example.project2.Controllers;
import com.example.project2.Project2Application;
import com.example.project2.Services.MessageService;
import com.example.project2.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

@Controller
public class MessageController {

    private final MessageService messageService;

    @Autowired
    public MessageController(MessageService messageService) {
        this.messageService = messageService;
    }

//    @GetMapping("/auth/content/{msgID}")
//    public String showPostDetails(@PathVariable int msgID, Model model) throws Exception {
//        if(Project2Application.currentUserID == 0){
//            return "redirect:/login";
//        }
//        Object[][] msg = messageService.getMessageByID(msgID);
//        model.addAttribute("msg", msg);
//        Object[][] reply = messageService.getReplyByMessageId(msgID);
//        model.addAttribute("reply", reply);
//        Hashtable<Object, Object[][]> replyReplyTable = new Hashtable<>();
//
//        for (Object[] row : reply) {
//            replyReplyTable.put(row[0], messageService.getReplyByReplyId((int) row[0]));
//
//        }
//
//        Map<Object, Object[][]> hashMap = new HashMap<>(replyReplyTable);
//        model.addAttribute("replyReplyMap", hashMap);
//        return "content";
//    }

    @GetMapping("/auth/content/{msgID}")
    public String showPostDetails(@PathVariable int msgID, Model model) throws Exception {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        Object[][] msg = messageService.getMessageByID(msgID);
        model.addAttribute("msg", msg);
        Object[][] reply = messageService.getReplyByMessageId(msgID);
        model.addAttribute("reply", reply);
        Hashtable<Object, Object[][]> replyReplyTable = new Hashtable<>();

        for (Object[] row : reply) {
            replyReplyTable.put(row[0], messageService.getReplyByReplyId((int) row[0]));

        }

        Map<Object, Object[][]> hashMap = new HashMap<>(replyReplyTable);
        model.addAttribute("replyReplyMap", hashMap);

        messageService.changeMsgRead(Project2Application.currentUserID, msgID);

        return "content";
    }

    @RequestMapping("/auth/content/{msgID}")
    public String replyMsg(@PathVariable int msgID, @RequestParam("replyContent") String replyContent, Model model) throws Exception {

        messageService.replyMsg(Project2Application.currentUserID, msgID, replyContent);

        return "redirect:/auth/content/" + msgID;
    }

    @RequestMapping("/auth/content/{msgID}/{replyID}")
    public String replyReply(@PathVariable int msgID, @PathVariable int replyID, @RequestParam("replyContent") String replyContent, Model model) throws Exception {

        messageService.replyReply(Project2Application.currentUserID, replyID, replyContent);

        return "redirect:/auth/content/" + msgID;
    }

}
