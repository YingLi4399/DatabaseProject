package com.example.project2.Controllers;

import com.example.project2.Project2Application;
import com.example.project2.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AccountController {

    @Autowired
    private UserService userService;

    @GetMapping("/auth/user/logged-in")
    public String showLoggedIn(Model model) {
        if(Project2Application.currentUserID != 0){
            return "redirect:/auth/user/" + Project2Application.currentUserID;
        }else {
            return "login";
        }

    }

    @GetMapping("/auth/user/{userID}")
    public String showAccount(@PathVariable int userID, Model model) {
        System.out.println("account page in?");
        if(Project2Application.currentUserID != 0){
            try {
                boolean hasBlock = false;
                Object[][] userInfo = userService.getUserInfo(userID);
                int relationCheck = userService.getUserRelation(userID);
                if (userInfo[0].length > 11) {
                    hasBlock = true;
                }
                model.addAttribute("loginUserID", Project2Application.currentUserID);
                model.addAttribute("relationCheck", relationCheck);
                model.addAttribute("userInfo", userInfo);
                model.addAttribute("hasBlock", hasBlock);
            } catch (Exception e) {
                e.printStackTrace();
                model.addAttribute("error", "Failed to load user information");
            }
            return "account";
        }else {
            return "login";
        }

    }

    @GetMapping("/auth/user/{userID}/edit")
    public String editAccount(@PathVariable int userID, Model model) {
        if(Project2Application.currentUserID != 0){
            try {
                Object[][] userInfo = userService.getUserInfo(userID);
                if (userInfo == null || userInfo.length == 0 || userInfo[0].length == 0) {
                    throw new Exception("User info is empty or not properly structured.");
                }
                Object[][] possibleAddresses = userService.getAllAddresses();
                model.addAttribute("userID", userID);
                model.addAttribute("userInfo", userInfo);
                model.addAttribute("possibleAddresses", possibleAddresses);
            } catch (Exception e) {
                e.printStackTrace();
                model.addAttribute("error", "Failed to load user information");
            }
            return "edit";
        }else {
            return "login";
        }



    }



    @PostMapping("/auth/user/{userID}/edit")
    public String updateAccount(@PathVariable int userID,
                                @RequestParam String address,
                                @RequestParam String location,
                                @RequestParam String familyDescription,
                                Model model) throws Exception{

        userService.updateUserDetails(userID, address, location, familyDescription);
        System.out.println("successes");
        return "redirect:/auth/user/" + userID; // Make sure this redirect is correct
    }

    @GetMapping("/auth/user/{userID}/add-neighbour")
    public String addNeighbour(@PathVariable int userID, Model model) throws Exception{

        if(Project2Application.currentUserID != 0){
            int currentUserID = Project2Application.currentUserID;
            userService.addNeighbour(currentUserID, userID);
            return "redirect:/auth/user/" + userID;
        }else {
            return "login";
        }

    }

    @GetMapping("/auth/user/{userID}/un-neighbour")
    public String unNeighbour(@PathVariable int userID, Model model) throws Exception{

        if(Project2Application.currentUserID != 0){
            int currentUserID = Project2Application.currentUserID;
            userService.unNeighbour(currentUserID, userID);
            return "redirect:/auth/user/" + userID;
        }else {
            return "login";
        }

    }

    @GetMapping("/auth/user/{userID}/add-friend")
    public String addFriend(@PathVariable int userID, Model model) throws Exception{

        if(Project2Application.currentUserID != 0){
            int currentUserID = Project2Application.currentUserID;
            userService.addFriend(currentUserID, userID);
            return "redirect:/auth/user/" + userID;
        }else {
            return "login";
        }

    }

    @GetMapping("/auth/user/{userID}/un-friend")
    public String unFriend(@PathVariable int userID, Model model) throws Exception{

        if(Project2Application.currentUserID != 0){
            int currentUserID = Project2Application.currentUserID;
            userService.unFriend(currentUserID, userID);
            return "redirect:/auth/user/" + userID;
        }else {
            return "login";
        }

    }

    @GetMapping("/auth/user/{userID}/cancel-friend-request")
    public String cancelFriendRequest(@PathVariable int userID, Model model) throws Exception{

        if(Project2Application.currentUserID != 0){
            int currentUserID = Project2Application.currentUserID;
            userService.cancelFriendRequest(currentUserID, userID);
            return "redirect:/auth/user/" + userID;
        }else {
            return "login";
        }

    }


}
