package com.example.project2.Controllers;

import com.example.project2.Project2Application;
import com.example.project2.Services.MessageService;
import com.example.project2.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ComposeController {

    private final MessageService messageService;
    private final UserService userService;

    @Autowired
    public ComposeController(MessageService messageService, UserService userService) {

        this.messageService = messageService;
        this.userService = userService;
    }

    @GetMapping("/auth/compose")
    public String composePost(Model model) throws Exception{

        if(Project2Application.currentUserID != 0){
            System.out.println("compose page");
            Object[][] neighbourList = userService.getNeighbours(Project2Application.currentUserID);
            Object[][] friendList = userService.getFriends(Project2Application.currentUserID);
            int isMember = messageService.getBlockIn(Project2Application.currentUserID);
            System.out.println("is member is: " + isMember);
            model.addAttribute("isMember", isMember);
            model.addAttribute("neighbourList", neighbourList);
            model.addAttribute("friendList", friendList);

            return "compose";
        }else {
            return "login";
        }


    }


    @PostMapping("/auth/compose")
    public String composeMessage(@RequestParam("title") String msgTitle,
                                 @RequestParam("message") String msgContent,
                                 @RequestParam("type") String type,
                                 @RequestParam("location") String location,
                                 @RequestParam(required = false, name = "friend") Object[] friend,
                                 @RequestParam(required = false, name = "neighbour") Object[] neighbour,
                                 Model model) throws Exception {


        int userId = Project2Application.currentUserID;
        System.out.println(type);
        if(type.equals("block") || type.equals("hood") || type.equals("all friend") || type.equals("all neighbour")){
            System.out.println("Block/Hood/All friend/All neighbour message composed");
            messageService.composeGeneralMessage(userId, location, msgTitle, msgContent, type);
        }else if(type.equals("certain_friend")){
            System.out.println("certain friend message composed");
            messageService.composePrivateMessage(userId, location, msgTitle, msgContent, type, Integer.parseInt((String)friend[0]) );
        }else if(type.equals("certain_neighbour")){
            System.out.println("certain neighbour message composed");
            messageService.composePrivateMessage(userId, location, msgTitle, msgContent, type, Integer.parseInt((String)neighbour[0]) );
        }


        return "redirect:/auth/feed/all";
    }

}
