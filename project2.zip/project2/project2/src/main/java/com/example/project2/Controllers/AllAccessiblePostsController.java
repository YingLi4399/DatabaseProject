package com.example.project2.Controllers;

import com.example.project2.Project2Application;
import com.example.project2.Services.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AllAccessiblePostsController {

    private final MessageService messageService;

    @Autowired
    public AllAccessiblePostsController(MessageService messageService) {
        this.messageService = messageService;
    }

    @GetMapping("/auth/posts/all")
    public String getAllAccessiblePosts(Model model) throws Exception {
        if (Project2Application.currentUserID == 0) {
            return "redirect:/login";
        }
        Object[][] result = messageService.getAllAccessiblePosts(Project2Application.currentUserID);
        model.addAttribute("message", result);
        model.addAttribute("userID", Project2Application.currentUserID);
        return "allAccessiblePosts";
    }

    @GetMapping("/auth/posts/block")
    public String getAllAccessibleBlockPosts(Model model) throws Exception {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        Object[][] result = messageService.getAllAccessibleBlockPosts(Project2Application.currentUserID);
        model.addAttribute("message", result);
        return "allAccessiblePosts";

    }

    @GetMapping("/auth/posts/hood")
    public String getAllAccessibleHoodPosts(Model model) throws Exception {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        Object[][] result = messageService.getAllAccessibleHoodPosts(Project2Application.currentUserID);
        model.addAttribute("message", result);
        return "allAccessiblePosts";

    }

    @GetMapping("/auth/posts/neighbour")
    public String getAllAccessibleNeighbourPosts(Model model) throws Exception {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        Object[][] result = messageService.getAllAccessibleNeighbourPosts(Project2Application.currentUserID);
        model.addAttribute("message", result);
        return "allAccessiblePosts";

    }

    @GetMapping("/auth/posts/friend")
    public String getAllAccessibleFriendPosts(Model model) throws Exception {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        Object[][] result = messageService.getAllAccessibleFriendPosts(Project2Application.currentUserID);
        model.addAttribute("message", result);
        return "allAccessiblePosts";

    }
}
