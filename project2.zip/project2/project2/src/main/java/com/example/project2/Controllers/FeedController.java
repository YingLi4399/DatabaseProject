package com.example.project2.Controllers;


import com.example.project2.Project2Application;
import com.example.project2.Services.MessageService;
import com.example.project2.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class FeedController {

    private final MessageService messageService;

    @Autowired
    public FeedController(MessageService messageService) {
        this.messageService = messageService;
    }



    @GetMapping("/auth/feed/all")
    public String getAllFeed(Model model) throws Exception {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        System.out.println(Project2Application.currentUserID);
        Object[][] result = messageService.getAllFeed(Project2Application.currentUserID);
        model.addAttribute("message", result);
        model.addAttribute("userID", Project2Application.currentUserID);
        return "feed";
    }


    @GetMapping("/auth/feed/block")
    public String getBlockFeed(Model model) throws Exception {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        Object[][] result = messageService.getBlockFeed(Project2Application.currentUserID);
        model.addAttribute("message", result);
        return "feed";

    }

    @GetMapping("/auth/feed/hood")
    public String getHoodFeed(Model model) throws Exception {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        Object[][] result = messageService.getHoodFeed(Project2Application.currentUserID);
        model.addAttribute("message", result);
        return "feed";

    }

    @GetMapping("/auth/feed/neighbour")
    public String getNeighbourFeed(Model model) throws Exception {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        Object[][] result = messageService.getNeighbourFeed(Project2Application.currentUserID);
        model.addAttribute("message", result);
        return "feed";

    }

    @GetMapping("/auth/feed/friend")
    public String getFriendFeed(Model model) throws Exception {
        if(Project2Application.currentUserID == 0){
            return "redirect:/login";
        }
        Object[][] result = messageService.getFriendFeed(Project2Application.currentUserID);
        model.addAttribute("message", result);
        return "feed";

    }



}