package com.example.project2.Controllers;


import com.example.project2.Project2Application;
import com.example.project2.Services.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    private final UserService userService;
    private final Project2Application project2Application;

    @Autowired
    public LoginController(UserService userService, Project2Application project2Application) {
        this.userService = userService;
        this.project2Application = project2Application;
    }


    @GetMapping("/")
    public String login(Model model) throws Exception {

        return "redirect:/login";

    }


    @GetMapping("/login")
    public String login() {

        if(Project2Application.currentUserID != 0){
            return "redirect:/auth/feed/all";
        }else{
            return "login";
        }
    }



    @PostMapping("/login")
    public String login(@RequestParam("username") String username,
                        @RequestParam("password") String password, Model model) throws Exception {

        System.out.println("get in login check");

            int resultNum = userService.loginCheck(username, password);
            if (resultNum == 0) {
                if(Project2Application.currentUserID==0){
                    Project2Application.currentUserID = userService.getUserID(username);
                }

                return "redirect:/auth/feed/all"; // Redirect to homepage or dashboard on successful login
            } else if (resultNum == 1) {
                model.addAttribute("errorMsg", "Invalid password!");
                return "404"; // Stay on login page and show error
            } else if (resultNum == 2) {
                model.addAttribute("errorMsg", "User does not exist!");
                return "404"; // Stay on login page and show error
            }

        model.addAttribute("errorMsg", "Unkown error happened, please retry");
        return "404"; // Stay on login page and show error

    }

    @GetMapping("/register")
    public String register(Model model) throws Exception {
        if(Project2Application.currentUserID != 0){
            return "redirect:/auth/feed/all";
        }else{
            return "register";
        }
    }

    @PostMapping("/register")
    public String register(@RequestParam("account") String account,
                           @RequestParam("password") String password,
                           @RequestParam("firstName") String firstName,
                           @RequestParam("lastName") String lastName,
                           @RequestParam("email") String email,
                           @RequestParam("address") String address,
                           @RequestParam("location") String location,
                           Model model) throws Exception {


        System.out.println("register");


        int resultNum = userService.register(account, password, firstName, lastName, email, address, location);
        if (resultNum == 1) {
            return "redirect:/login"; // Redirect to homepage or dashboard on successful login
        } else {
            model.addAttribute("errorMsg", "Account already existed!");
            return "404"; // Stay on login page and show error
        }

    }


    @GetMapping("/forgot-password")
    public String changePassword(Model model) throws Exception {
        if(Project2Application.currentUserID != 0){
            return "redirect:/auth/feed/all";
        }else {
            return "password";
        }
    }

    @PostMapping("/forgot-password")
    public String changePassword(@RequestParam("account") String account,
                                 @RequestParam("email") String email,
                                 @RequestParam("password") String password,
                                 Model model) throws Exception {

        System.out.println("change password");

        int resultNum = userService.changePassword(account, email, password);
        if (resultNum == 0) {
            return "redirect:/login"; // Redirect to homepage or dashboard on successful login
        } else if (resultNum == 1) {
            model.addAttribute("errorMsg", "Account doesnt exist!");
            return "404"; // Stay on login page and show error
        } else{
            model.addAttribute("errorMsg", "email is incorrect!");
            return "404"; // Stay on login page and show error
        }
    }

    @GetMapping("/logout")
    public String logout(Model model) throws Exception {
            Project2Application.currentUserID = 0;
            return "login";

    }

}