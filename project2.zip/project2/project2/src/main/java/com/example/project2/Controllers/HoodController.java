package com.example.project2.Controllers;

import com.example.project2.Project2Application;
import com.example.project2.Services.HoodService;
import com.example.project2.Services.MessageService;
import com.example.project2.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class HoodController {

    @Autowired
    private HoodService hoodService;
    private UserService userService;
    public HoodController(HoodService hoodService, UserService userService) {
        this.userService = userService;
        this.hoodService = hoodService;
    }

    @GetMapping("/auth/hood")
    public String showHoods(Model model) {
        if(Project2Application.currentUserID != 0){

            try {
                model.addAttribute("hoods", hoodService.getAllHoods());
            } catch (Exception e) {
                e.printStackTrace();
                // Handle exceptions appropriately
            }
            return "hood";
        }else {
            return "login";
        }


    }

    @GetMapping("/auth/hood/posts/{hoodID}")
    public String showHoodPosts(@PathVariable("hoodID") Integer hoodID, Model model) {
        if(Project2Application.currentUserID != 0){

            try {
                boolean blockMember = userService.getUserHoodStatus(Project2Application.currentUserID, hoodID);
                if(blockMember){
                    model.addAttribute("hoodPosts", hoodService.getHoodPosts(hoodID));

                }else{
                    model.addAttribute("hoodPosts", null);
                }
                model.addAttribute("hoodInfo", hoodService.getHoodInfo(hoodID));
            } catch (Exception e) {
                e.printStackTrace();
                // Handle exceptions appropriately
            }
            return "hoodPosts";
        }else {
            return "login";
        }


    }
}
