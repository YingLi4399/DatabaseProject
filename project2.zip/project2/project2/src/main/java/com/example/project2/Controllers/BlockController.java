//package com.example.project2.Controllers;
//
//import com.example.project2.Services.BlockService;
//import com.example.project2.Services.MessageService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//
//@Controller
//public class BlockController {
//
//    @Autowired
//    private BlockService blockService;
//
//    public BlockController(MessageService messageService) {
//        this.blockService = blockService;
//    }
//
//    @GetMapping("/auth/block")
//    public String showBlocks(Model model) {
//        try {
//            model.addAttribute("blocks", blockService.getAllBlocks());
//            model.addAttribute("hoods", blockService.getAllHoods());
//        } catch (Exception e) {
//            e.printStackTrace();
//            // Handle exceptions appropriately
//        }
//        return "block";
//    }
//}
package com.example.project2.Controllers;

import com.example.project2.Project2Application;
import com.example.project2.Services.BlockService;
import com.example.project2.Services.MessageService;
import com.example.project2.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class BlockController {

    private final BlockService blockService;
    private final UserService userService;

    @Autowired
    public BlockController(BlockService blockService, UserService userService) {
        this.blockService = blockService;
        this.userService = userService;
    }

    @GetMapping("/auth/block")
    public String showBlocks(Model model) {
        if(Project2Application.currentUserID != 0){

            try {
                model.addAttribute("blocks", blockService.getAllBlocks());
            } catch (Exception e) {
                e.printStackTrace();
                // Handle exceptions appropriately
            }
            return "block";
        }else {
            return "login";
        }


    }

    @GetMapping("/auth/block/posts/{blockID}")
    public String showBlockPosts(@PathVariable("blockID") Integer blockID, Model model) {
        if(Project2Application.currentUserID != 0){

            try {
                int status = userService.getUserBlockStatus(Project2Application.currentUserID, blockID);
                System.out.println("status is " + status);
                if(status == 1 || status == 2){
                    model.addAttribute("blockPosts", blockService.getBlockPosts(blockID));
                }else{
                    model.addAttribute("blockPosts", null);
                }
                model.addAttribute("blockInfo", blockService.getBlockInfo(blockID));

                model.addAttribute("status", status);
            } catch (Exception e) {
                e.printStackTrace();
                // Handle exceptions appropriately
            }
            return "blockPosts";
        }else {
            return "login";
        }


    }

    @GetMapping("/auth/block/posts/{blockID}/follow")
    public String followBlock(@PathVariable("blockID") Integer blockID, Model model) throws Exception {
        if(Project2Application.currentUserID != 0){

            userService.followBlock(Project2Application.currentUserID, blockID);
            return "redirect:/auth/block/posts/" + blockID;
        }else {
            return "login";
        }


    }

    @GetMapping("/auth/block/posts/{blockID}/unfollow")
    public String unfollowBlock(@PathVariable("blockID") Integer blockID, Model model) throws Exception {
        if(Project2Application.currentUserID != 0){

            userService.unfollowBlock(Project2Application.currentUserID, blockID);
            return "redirect:/auth/block/posts/" + blockID;
        }else {
            return "login";
        }


    }

    @GetMapping("/auth/block/posts/{blockID}/apply")
    public String applyBlock(@PathVariable("blockID") Integer blockID, Model model) throws Exception {
        if(Project2Application.currentUserID != 0){

            userService.applyBlock(Project2Application.currentUserID, blockID);
            return "redirect:/auth/block/posts/" + blockID;
        }else {
            return "login";
        }


    }

    @GetMapping("/auth/block/posts/{blockID}/unmember")
    public String unmemberBlock(@PathVariable("blockID") Integer blockID, Model model) throws Exception {
        if(Project2Application.currentUserID != 0){

            userService.unmemberBlock(Project2Application.currentUserID, blockID);
            return "redirect:/auth/block/posts/" + blockID;
        }else {
            return "login";
        }


    }
}
