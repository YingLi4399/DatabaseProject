package com.example.project2.Services;

import org.springframework.stereotype.Component;

import java.sql.*;

@Component
public class BlockService {
    private String url = "jdbc:postgresql://localhost:5432/DatabaseProject";
    private String user = "postgres";
    private String password = "";
    private Connection con;
    private Statement st;
    private ResultSet rs;

    public BlockService() {
        try {
            // Create database connection
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Close resources
    public void close() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Object[][] getAllBlocks() throws Exception {
        String sql = "SELECT * FROM public.block";
        rs = st.executeQuery(sql);
        return generateArray();
    }

    public Object[][] getAllHoods() throws Exception {
        String sql = "SELECT * FROM public.hood";
        rs = st.executeQuery(sql);
        return generateArray();
    }

    public Object[][] getBlockPosts(int blockID) throws Exception {
        String sql = "SELECT * \n" +
                "FROM public.\"blockMessage\" b \n" +
                "JOIN public.\"message\" m\n" +
                "ON b.msg_id = m.msg_id\n" +
                "WHERE block_id = " + blockID;
        rs = st.executeQuery(sql);
        return generateArray();
    }

    public Object[] getBlockInfo(Integer blockID) throws Exception {
        String sql = "SELECT * FROM public.block\n" +
                "WHERE block_id = " + blockID;
        rs = st.executeQuery(sql);
        return generateArray();
    }

    private Object[][] generateArray() throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int numColumns = rsmd.getColumnCount();
        Object[][] array;
        rs.last();
        int numRows = rs.getRow();
        rs.beforeFirst();

        array = new Object[numRows][numColumns];
        int row = 0;
        while (rs.next()) {
            for (int col = 0; col < numColumns; col++) {
                array[row][col] = rs.getObject(col + 1);
            }
            row++;
        }
        return array;
    }
}
