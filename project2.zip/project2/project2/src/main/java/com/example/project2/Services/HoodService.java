package com.example.project2.Services;


import org.springframework.stereotype.Component;

import java.sql.*;

@Component
public class HoodService {
    private String url = "jdbc:postgresql://localhost:5432/DatabaseProject";
    private String user = "postgres";
    private String password = "";
    private Connection con;
    private Statement st;
    private ResultSet rs;

    public HoodService() {
        try {
            // Create database connection
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Close resources
    public void close() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Object[][] getAllHoods() throws Exception {
        String sql = "SELECT * FROM public.hood";
        rs = st.executeQuery(sql);
        return generateArray();
    }

    private Object[][] generateArray() throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int numColumns = rsmd.getColumnCount();
        Object[][] array;
        rs.last();
        int numRows = rs.getRow();
        rs.beforeFirst();

        array = new Object[numRows][numColumns];
        int row = 0;
        while (rs.next()) {
            for (int col = 0; col < numColumns; col++) {
                array[row][col] = rs.getObject(col + 1);
            }
            row++;
        }
        return array;
    }

    public Object[][] getHoodPosts(Integer hoodID) throws Exception {
        String sql = "SELECT * \n" +
                "FROM public.\"hoodMessage\" h\n" +
                "JOIN public.\"message\" m ON h.msg_id=m.msg_id\n" +
                "WHERE hood_id = " + hoodID;
        rs = st.executeQuery(sql);
        return generateArray();
    }

    public Object[][] getHoodInfo(Integer hoodID) throws Exception {
        String sql = "SELECT * \n" +
                "FROM public.\"hood\" h\n" +
                "WHERE hood_id = " + hoodID;
        rs = st.executeQuery(sql);
        return generateArray();
    }

}
